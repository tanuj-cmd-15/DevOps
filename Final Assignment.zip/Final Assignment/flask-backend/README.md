# Flask Backend API

A RESTful API built with Flask for managing items with CRUD operations.

## Features

- ✅ RESTful API endpoints
- ✅ CORS enabled for frontend communication
- ✅ Health check endpoint
- ✅ In-memory data storage
- ✅ Error handling
- ✅ JSON responses

## API Endpoints

### Base URL
```
http://<server-ip>:5000
```

### Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/` | API information |
| GET | `/api/health` | Health check |
| GET | `/api/items` | Get all items |
| GET | `/api/items/:id` | Get item by ID |
| POST | `/api/items` | Create new item |
| PUT | `/api/items/:id` | Update item |
| DELETE | `/api/items/:id` | Delete item |

## Setup Instructions

### Local Development

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd flask-backend
   ```

2. **Create virtual environment**
   ```bash
   python3 -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   ```

3. **Install dependencies**
   ```bash
   pip install -r requirements.txt
   ```

4. **Run the application**
   ```bash
   python app.py
   ```

5. **Test the API**
   ```bash
   curl http://localhost:5000/api/health
   ```

### Production Deployment (EC2)

1. **Install dependencies on EC2**
   ```bash
   sudo apt update
   sudo apt install python3 python3-pip python3-venv -y
   ```

2. **Clone and setup**
   ```bash
   git clone <repository-url>
   cd flask-backend
   python3 -m venv venv
   source venv/bin/activate
   pip install -r requirements.txt
   ```

3. **Run with PM2**
   ```bash
   pm2 start "source venv/bin/activate && python app.py" --name flask-backend
   pm2 save
   pm2 startup
   ```

## API Usage Examples

### Get all items
```bash
curl http://localhost:5000/api/items
```

### Create new item
```bash
curl -X POST http://localhost:5000/api/items \
  -H "Content-Type: application/json" \
  -d '{"name":"New Item","description":"Item description"}'
```

### Update item
```bash
curl -X PUT http://localhost:5000/api/items/1 \
  -H "Content-Type: application/json" \
  -d '{"name":"Updated Item","description":"Updated description"}'
```

### Delete item
```bash
curl -X DELETE http://localhost:5000/api/items/1
```

## Environment Variables

- `PORT` - Server port (default: 5000)

## Dependencies

- Flask - Web framework
- flask-cors - CORS support
- gunicorn - Production server

## Jenkins CI/CD

This project includes a `Jenkinsfile` for automated deployment:

- Pulls latest code from Git
- Sets up virtual environment
- Installs dependencies
- Runs tests (optional)
- Restarts application with PM2
- Performs health check

## Testing

Run tests (when implemented):
```bash
pytest tests/
```

## License

MIT License
"# Updated for webhook test" 
