from flask import Flask, jsonify, request
from flask_cors import CORS
from datetime import datetime
import os

app = Flask(__name__)
CORS(app)  # Enable CORS for frontend communication

# In-memory data store (replace with database in production)
items = [
    {"id": 1, "name": "Sample Item 1", "description": "This is a sample item", "created_at": "2026-09-04"},
    {"id": 2, "name": "Sample Item 2", "description": "Another sample item", "created_at": "2026-09-04"}
]

next_id = 3

@app.route('/')
def home():
    """Root endpoint"""
    return jsonify({
        "message": "Flask Backend API",
        "version": "1.0.0",
        "endpoints": {
            "health": "/api/health",
            "items": "/api/items",
            "item_by_id": "/api/items/<id>"
        }
    })

@app.route('/api/health', methods=['GET'])
def health_check():
    """Health check endpoint"""
    return jsonify({
        "status": "healthy",
        "message": "Flask backend is running",
        "timestamp": datetime.now().isoformat()
    })

@app.route('/api/items', methods=['GET'])
def get_items():
    """Get all items"""
    return jsonify({
        "success": True,
        "count": len(items),
        "items": items
    })

@app.route('/api/items/<int:item_id>', methods=['GET'])
def get_item(item_id):
    """Get a specific item by ID"""
    item = next((item for item in items if item['id'] == item_id), None)
    if item:
        return jsonify({
            "success": True,
            "item": item
        })
    return jsonify({
        "success": False,
        "message": "Item not found"
    }), 404

@app.route('/api/items', methods=['POST'])
def create_item():
    """Create a new item"""
    global next_id
    
    data = request.get_json()
    
    if not data or 'name' not in data:
        return jsonify({
            "success": False,
            "message": "Name is required"
        }), 400
    
    new_item = {
        "id": next_id,
        "name": data['name'],
        "description": data.get('description', ''),
        "created_at": datetime.now().strftime("%Y-%m-%d")
    }
    
    items.append(new_item)
    next_id += 1
    
    return jsonify({
        "success": True,
        "message": "Item created successfully",
        "item": new_item
    }), 201

@app.route('/api/items/<int:item_id>', methods=['PUT'])
def update_item(item_id):
    """Update an existing item"""
    item = next((item for item in items if item['id'] == item_id), None)
    
    if not item:
        return jsonify({
            "success": False,
            "message": "Item not found"
        }), 404
    
    data = request.get_json()
    
    if 'name' in data:
        item['name'] = data['name']
    if 'description' in data:
        item['description'] = data['description']
    
    return jsonify({
        "success": True,
        "message": "Item updated successfully",
        "item": item
    })

@app.route('/api/items/<int:item_id>', methods=['DELETE'])
def delete_item(item_id):
    """Delete an item"""
    global items
    
    item = next((item for item in items if item['id'] == item_id), None)
    
    if not item:
        return jsonify({
            "success": False,
            "message": "Item not found"
        }), 404
    
    items = [item for item in items if item['id'] != item_id]
    
    return jsonify({
        "success": True,
        "message": "Item deleted successfully"
    })

@app.errorhandler(404)
def not_found(error):
    """Handle 404 errors"""
    return jsonify({
        "success": False,
        "message": "Endpoint not found"
    }), 404

@app.errorhandler(500)
def internal_error(error):
    """Handle 500 errors"""
    return jsonify({
        "success": False,
        "message": "Internal server error"
    }), 500

if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5000))
    app.run(host='0.0.0.0', port=port, debug=False)
