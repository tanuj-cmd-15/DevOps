// API Base URL
const API_BASE = window.location.origin;

// State
let items = [];
let editingItemId = null;

// Initialize
document.addEventListener('DOMContentLoaded', () => {
    loadItems();
    checkBackendStatus();
    setupEventListeners();
});

// Setup event listeners
function setupEventListeners() {
    const form = document.getElementById('itemForm');
    if (form) {
        form.addEventListener('submit', handleFormSubmit);
    }
}

// Check backend status
async function checkBackendStatus() {
    try {
        const response = await fetch(`${API_BASE}/health`);
        const data = await response.json();
        
        updateStatus('frontend', data.frontend === 'healthy');
        updateStatus('backend', data.backend && data.backend.status === 'healthy');
    } catch (error) {
        console.error('Error checking backend status:', error);
        updateStatus('frontend', true);
        updateStatus('backend', false);
    }
}

// Update status badge
function updateStatus(type, isOnline) {
    const badge = document.getElementById(`${type}Status`);
    if (badge) {
        badge.textContent = isOnline ? 'Online' : 'Offline';
        badge.className = `status-badge ${isOnline ? 'status-online' : 'status-offline'}`;
    }
}

// Load items from API
async function loadItems() {
    const itemsList = document.getElementById('itemsList');
    if (!itemsList) return;
    
    itemsList.innerHTML = '<div class="loading">Loading items...</div>';
    
    try {
        const response = await fetch(`${API_BASE}/api/items`);
        const data = await response.json();
        
        if (data.success && data.items) {
            items = data.items;
            renderItems();
        } else {
            throw new Error('Failed to load items');
        }
    } catch (error) {
        console.error('Error loading items:', error);
        itemsList.innerHTML = `
            <div class="error">
                <strong>Error:</strong> Could not load items. Make sure the backend is running.
            </div>
        `;
    }
}

// Render items
function renderItems() {
    const itemsList = document.getElementById('itemsList');
    if (!itemsList) return;
    
    if (items.length === 0) {
        itemsList.innerHTML = `
            <div class="empty-state">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" 
                          d="M20 13V6a2 2 0 00-2-2H6a2 2 0 00-2 2v7m16 0v5a2 2 0 01-2 2H6a2 2 0 01-2-2v-5m16 0h-2.586a1 1 0 00-.707.293l-2.414 2.414a1 1 0 01-.707.293h-3.172a1 1 0 01-.707-.293l-2.414-2.414A1 1 0 006.586 13H4">
                    </path>
                </svg>
                <p>No items yet. Create your first item!</p>
            </div>
        `;
        return;
    }
    
    itemsList.innerHTML = items.map(item => `
        <li class="item">
            <div class="item-header">
                <span class="item-name">${escapeHtml(item.name)}</span>
                <div class="item-actions">
                    <button class="btn btn-success" onclick="editItem(${item.id})">Edit</button>
                    <button class="btn btn-danger" onclick="deleteItem(${item.id})">Delete</button>
                </div>
            </div>
            <p class="item-description">${escapeHtml(item.description)}</p>
            <p class="item-meta">Created: ${item.created_at} | ID: ${item.id}</p>
        </li>
    `).join('');
}

// Handle form submit
async function handleFormSubmit(e) {
    e.preventDefault();
    
    const name = document.getElementById('itemName').value.trim();
    const description = document.getElementById('itemDescription').value.trim();
    
    if (!name) {
        showMessage('Please enter an item name', 'error');
        return;
    }
    
    const itemData = { name, description };
    
    try {
        let response;
        if (editingItemId) {
            // Update existing item
            response = await fetch(`${API_BASE}/api/items/${editingItemId}`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(itemData)
            });
        } else {
            // Create new item
            response = await fetch(`${API_BASE}/api/items`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(itemData)
            });
        }
        
        const data = await response.json();
        
        if (data.success) {
            showMessage(data.message, 'success');
            resetForm();
            loadItems();
        } else {
            throw new Error(data.message || 'Operation failed');
        }
    } catch (error) {
        console.error('Error saving item:', error);
        showMessage('Error: ' + error.message, 'error');
    }
}

// Edit item
function editItem(id) {
    const item = items.find(i => i.id === id);
    if (!item) return;
    
    document.getElementById('itemName').value = item.name;
    document.getElementById('itemDescription').value = item.description;
    document.getElementById('formTitle').textContent = 'Edit Item';
    document.getElementById('submitBtn').textContent = 'Update Item';
    
    editingItemId = id;
    
    // Scroll to form
    document.getElementById('itemForm').scrollIntoView({ behavior: 'smooth' });
}

// Delete item
async function deleteItem(id) {
    if (!confirm('Are you sure you want to delete this item?')) {
        return;
    }
    
    try {
        const response = await fetch(`${API_BASE}/api/items/${id}`, {
            method: 'DELETE'
        });
        
        const data = await response.json();
        
        if (data.success) {
            showMessage(data.message, 'success');
            loadItems();
        } else {
            throw new Error(data.message || 'Delete failed');
        }
    } catch (error) {
        console.error('Error deleting item:', error);
        showMessage('Error: ' + error.message, 'error');
    }
}

// Reset form
function resetForm() {
    document.getElementById('itemForm').reset();
    document.getElementById('formTitle').textContent = 'Add New Item';
    document.getElementById('submitBtn').textContent = 'Add Item';
    editingItemId = null;
}

// Show message
function showMessage(message, type) {
    const existingMessage = document.querySelector('.message');
    if (existingMessage) {
        existingMessage.remove();
    }
    
    const messageDiv = document.createElement('div');
    messageDiv.className = `${type} message`;
    messageDiv.textContent = message;
    
    const form = document.getElementById('itemForm');
    form.insertBefore(messageDiv, form.firstChild);
    
    setTimeout(() => {
        messageDiv.remove();
    }, 3000);
}

// Escape HTML
function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

// Auto-refresh items every 30 seconds
setInterval(() => {
    loadItems();
}, 30000);
