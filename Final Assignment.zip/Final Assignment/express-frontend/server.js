const express = require('express');
const path = require('path');
const axios = require('axios');

const app = express();
const PORT = process.env.PORT || 3000;
const FLASK_API_URL = process.env.FLASK_API_URL || 'http://localhost:5000';

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

// Set view engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Routes
app.get('/', (req, res) => {
    res.render('index', { 
        title: 'Express Frontend',
        apiUrl: FLASK_API_URL 
    });
});

app.get('/health', async (req, res) => {
    try {
        const response = await axios.get(`${FLASK_API_URL}/api/health`);
        res.json({
            frontend: 'healthy',
            backend: response.data
        });
    } catch (error) {
        res.status(500).json({
            frontend: 'healthy',
            backend: 'unhealthy',
            error: error.message
        });
    }
});

// Proxy routes to Flask backend
app.get('/api/items', async (req, res) => {
    try {
        const response = await axios.get(`${FLASK_API_URL}/api/items`);
        res.json(response.data);
    } catch (error) {
        res.status(500).json({ 
            success: false, 
            message: 'Error fetching items from backend',
            error: error.message 
        });
    }
});

app.post('/api/items', async (req, res) => {
    try {
        const response = await axios.post(`${FLASK_API_URL}/api/items`, req.body);
        res.json(response.data);
    } catch (error) {
        res.status(500).json({ 
            success: false, 
            message: 'Error creating item',
            error: error.message 
        });
    }
});

app.put('/api/items/:id', async (req, res) => {
    try {
        const response = await axios.put(`${FLASK_API_URL}/api/items/${req.params.id}`, req.body);
        res.json(response.data);
    } catch (error) {
        res.status(500).json({ 
            success: false, 
            message: 'Error updating item',
            error: error.message 
        });
    }
});

app.delete('/api/items/:id', async (req, res) => {
    try {
        const response = await axios.delete(`${FLASK_API_URL}/api/items/${req.params.id}`);
        res.json(response.data);
    } catch (error) {
        res.status(500).json({ 
            success: false, 
            message: 'Error deleting item',
            error: error.message 
        });
    }
});

// 404 handler
app.use((req, res) => {
    res.status(404).render('404', { title: '404 - Not Found' });
});

// Error handler
app.use((err, req, res, next) => {
    console.error(err.stack);
    res.status(500).json({ 
        success: false, 
        message: 'Internal server error' 
    });
});

// Start server
app.listen(PORT, '0.0.0.0', () => {
    console.log(`Express frontend running on port ${PORT}`);
    console.log(`Flask backend URL: ${FLASK_API_URL}`);
    console.log(`Visit: http://localhost:${PORT}`);
});
