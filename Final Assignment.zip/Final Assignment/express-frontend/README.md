# Express Frontend

A web application built with Express.js that interfaces with the Flask backend API.

## Features

- ✅ Modern, responsive UI
- ✅ Real-time communication with Flask backend
- ✅ CRUD operations for items
- ✅ Health monitoring for both frontend and backend
- ✅ Auto-refresh functionality
- ✅ Error handling and user feedback

## Tech Stack

- **Express.js** - Web framework
- **EJS** - Template engine
- **Axios** - HTTP client
- **Vanilla JavaScript** - Frontend interactivity
- **CSS3** - Styling with gradients and animations

## Setup Instructions

### Local Development

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd express-frontend
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Set environment variables (optional)**
   ```bash
   export PORT=3000
   export FLASK_API_URL=http://localhost:5000
   ```

4. **Run the application**
   ```bash
   npm start
   ```

   For development with auto-reload:
   ```bash
   npm run dev
   ```

5. **Access the application**
   ```
   http://localhost:3000
   ```

### Production Deployment (EC2)

1. **Install Node.js on EC2**
   ```bash
   curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
   sudo apt install nodejs -y
   sudo npm install -g pm2
   ```

2. **Clone and setup**
   ```bash
   git clone <repository-url>
   cd express-frontend
   npm install
   ```

3. **Configure environment**
   ```bash
   export FLASK_API_URL=http://localhost:5000
   ```

4. **Run with PM2**
   ```bash
   pm2 start npm --name express-frontend -- start
   pm2 save
   pm2 startup
   ```

## Application Structure

```
express-frontend/
├── server.js           # Main Express server
├── package.json        # Dependencies and scripts
├── Jenkinsfile        # CI/CD pipeline configuration
├── public/            # Static assets
│   ├── style.css      # Application styles
│   └── script.js      # Frontend JavaScript
├── views/             # EJS templates
│   ├── index.ejs      # Main page
│   └── 404.ejs        # Error page
└── README.md          # This file
```

## API Routes

### Frontend Routes
- `GET /` - Main application page
- `GET /health` - Health check endpoint

### API Proxy Routes (to Flask backend)
- `GET /api/items` - Get all items
- `POST /api/items` - Create new item
- `PUT /api/items/:id` - Update item
- `DELETE /api/items/:id` - Delete item

## Environment Variables

- `PORT` - Server port (default: 3000)
- `FLASK_API_URL` - Flask backend URL (default: http://localhost:5000)

## Features in Detail

### Health Monitoring
The application includes a status bar that shows:
- Express Frontend status
- Flask Backend status
- Current backend URL

### Item Management
Users can:
- View all items in a responsive list
- Create new items with name and description
- Edit existing items
- Delete items with confirmation
- Auto-refresh every 30 seconds

### User Interface
- Modern gradient design
- Responsive layout (mobile-friendly)
- Smooth animations and transitions
- Loading states and error handling
- Empty state for no items

## Jenkins CI/CD

This project includes a `Jenkinsfile` for automated deployment:

- Pulls latest code from Git
- Installs npm dependencies
- Runs tests (optional)
- Restarts application with PM2
- Performs health check

## Testing

Test the application:

```bash
# Test health endpoint
curl http://localhost:3000/health

# Test main page
curl http://localhost:3000
```

## Troubleshooting

### Port Already in Use
```bash
sudo lsof -i :3000
kill -9 <PID>
```

### Backend Connection Issues
- Ensure Flask backend is running on port 5000
- Check FLASK_API_URL environment variable
- Verify network connectivity

### PM2 Issues
```bash
pm2 delete express-frontend
pm2 start npm --name express-frontend -- start
pm2 logs express-frontend
```

## Development

### Run in Development Mode
```bash
npm run dev
```

This uses `nodemon` for auto-reloading on code changes.

### Make Changes
1. Edit files in `public/`, `views/`, or `server.js`
2. Changes will auto-reload in development mode
3. Test your changes
4. Commit and push to trigger Jenkins pipeline

## License

MIT License
"# Updated for webhook test" 
